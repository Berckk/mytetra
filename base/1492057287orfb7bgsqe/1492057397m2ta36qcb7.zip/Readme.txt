Requires .Net Framework 4.52+ (Windows Vista+/Server 2008+). If not installed, download here https://www.microsoft.com/en-us/download/details.aspx?id=42642

No actions required in addition to the system requirements for installing program. You can run program from any catalog, but the program will use single settings and database, stored in Windows user profile, in normal mode and in program catalog - in portable mode. To autostart program on user logon, you have to turn on appropriate checkbox in Settings window.

ClipAngelPortable.bat - runs application in portable mode, settings and database will be loaded/saved in the same catalog, where program is started.